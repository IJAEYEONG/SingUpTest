export default function(Element){
  const test  =document.getElementById(Element);
  return test;
}