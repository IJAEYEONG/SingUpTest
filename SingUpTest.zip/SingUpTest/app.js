import name from "./names.js";
import getElementById from "./getElementID.js";



function updateValidationMessage(element, message, color) {
  element.innerHTML = message;
  element.style.color = color;
}
function validateName(nameInputValue, IdResult, checkbox2) {
  if (name.includes(nameInputValue)) {
    updateValidationMessage(IdResult, '이름이 맞습니다.', 'green');
    checkbox2.style.backgroundColor = 'green';
  } else if (nameInputValue === '') {
    updateValidationMessage(IdResult, '값이 비어있습니다.', 'red');
    checkbox2.style.backgroundColor = 'red';
  } else {
    updateValidationMessage(IdResult, '이름이 틀립니다.', 'red');
    checkbox2.style.backgroundColor = 'red';
  }
}

function validateEmail(email, resultDiv, emilbox_checkbox) {
  const Emailpattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
  if (Emailpattern.test(email)) {
    updateValidationMessage(resultDiv, '유효한 이메일 주소입니다.', 'green');
    emilbox_checkbox.style.backgroundColor = 'green';
    return true;
  }else if(email === ''){
    updateValidationMessage(resultDiv , '값이 비어있습니다.','red');
    emilbox_checkbox.style.backgroundColor='red';
  } else {
    updateValidationMessage(resultDiv, '유효하지 않은 이메일 주소입니다.', 'red');
    emilbox_checkbox.style.backgroundColor = 'red';
    return false;
  }
}
function validatePassword(newPassword, confirmPassword, passwordResultDiv) {
    const passwordbox = document.querySelector('.password_checkbox');
    const password2_box = document.querySelector('.password2_checkbox');
    const passwordRegex = /^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$%^&*?_]).{8,16}$/;
  if (passwordRegex.test(newPassword)) {
    if (newPassword === confirmPassword) {
      updateValidationMessage(passwordResultDiv, '비밀번호가 일치하며 유효합니다.', 'green');
      passwordbox.style.backgroundColor="green"
      password2_box.style.backgroundColor="green"
      return true;
    }else if(newPassword ===''&& confirmPassword===''){
      updateValidationMessage(passwordResultDiv,'값이 비어있습니다.','red');
      passwordbox.style.backgroundColor="red"
      password2_box.style.backgroundColor="red"
    } else {
      updateValidationMessage(passwordResultDiv, '비밀번호가 일치하지 않습니다.', 'red');
      passwordbox.style.backgroundColor="red"
      password2_box.style.backgroundColor="red"
      return false;
    }
  } else {
    updateValidationMessage(passwordResultDiv, '비밀번호는 최소 8자에서 16자까지, 영문자, 숫자 및 특수 문자를 포함해야 합니다.', 'red');
    passwordbox.style.backgroundColor="red"
    return false;
  }
}
function validatePhonNumber(phone, PhoneResult, phone_checkbox) {
  const Phonepattern =/^\d{3}-\d{3,4}-\d{4}$/;
  if (Phonepattern.test(phone)) {
    updateValidationMessage(PhoneResult, '유효한 핸드폰 번호입니다.', 'green');
    phone_checkbox.style.backgroundColor = 'green';
    return true;
  }else if(phone === ''){
    updateValidationMessage(PhoneResult,'값이 비어있습니다.','red')
    phone_checkbox.style.backgroundColor='red';
  } else {
    updateValidationMessage(PhoneResult, '유효하지않은  핸드폰 번호입니다.', 'red');
    phone_checkbox.style.backgroundColor = 'red';
    return false;
  }
}


function validateForm() {
  const checkbox = document.querySelector('.parent');
  const checkbox2 = checkbox.querySelector('.checkbox');
  const emilbox = document.querySelector('.email_box');
  const emilbox_checkbox = emilbox.querySelector('.checkbox');
  const emailInput = getElementById("email");
  const passwordInput = document.getElementById('newPassword');
  const confirmPasswordInput = document.getElementById('confirmPassword');
  const resultDiv = document.getElementById('result');
  const passwordResultDiv = document.getElementById('passwordResult');
  const nameInput = document.getElementById('username');
  const IdResult = document.getElementById('IdResult');
  const PhoneInput = document.getElementById('txtPhone')
  const PhoneResult =document.getElementById('phoneResult')
  const phone_checkbox=document.getElementById('phone_checkbox')


  const email = emailInput.value;
  const newPassword = passwordInput.value;
  const confirmPassword = confirmPasswordInput.value;
  const phone = PhoneInput.value;

  validateEmail(email, resultDiv, emilbox_checkbox);
  validatePassword(newPassword, confirmPassword, passwordResultDiv);
  validateName(nameInput.value, IdResult, checkbox2);
  validatePhonNumber(phone,PhoneResult,phone_checkbox)
}

window.validateForm = validateForm; // Make the function globally accessible

// document.addEventListener("DOMContentLoaded", function() {
//   const inputs = document.querySelectorAll("input[required]");
//   inputs.forEach(input => {
//     input.addEventListener("focus", () => {
//       input.style.border = input.value === "" ? "1px solid #ccc" : "1px solid green";
//     });
//     input.addEventListener("blur", () => {
//       input.style.border = input.value === "" ? "1px solid red" : "1px solid green";
//     });
//   });
// });
